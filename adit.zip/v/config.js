global.token = "8187348951:AAHaXlT5fURZUVtJ-tXdjyoGWvQc15IlTlI"
global.ownername = "Xfcas"
global.ownerid = "8162441899"
global.premid = "8162441899"
global.botname = "zixu asisten"
global.prefix = ["/", ".", "#", "!"]
global.wib = 7
global.wait = "tunggu sebentar ya kak/bang!😊."
global.wm = "© Zixu Asisten"
// Message
global.message = {
  rowner: "fitur eksklusif owner",
  owner: "fitur ini khusus untuk owner saja",
  premium: "perintah ini khusus anggota premium!",
  group: "perintah ini khusus untuk grup!",
  private: "perintah hanya bisa dalam obrolan pribadi ",
  admin: "perintah hanya khusus admin grup saja!",
  error: "Maaf ! terjadi kesalahan mohon coba kembali atau chat admin @Xfcas ",
};

// Port configuration
global.ports = [4000, 3000, 5000, 8000];

// Database configuration
global.limit = 100;

global.APIs = {
  //lann: 'https://api.betabotz.eu.org',
  ryzumi: 'https://api.ryzumi.vip',
  
}
global.APIKeys = {
  //'https://api.betabotz.eu.org': 'API_KEY', 
}

import fs from 'fs';
import chalk from 'chalk';

const file = new URL(import.meta.url);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.redBright(`Update 'config.js'`));
});
